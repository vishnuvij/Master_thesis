import os
import pandas as pd
from tqdm import tqdm

# Define functions (functions from previous code block remain unchanged)
def remove_unassigned_rows(df):
    return df[df['plot_label'] != "Unassigned"].copy()

def mark_target_rows(df):
    df['Target'] = None
    df.loc[df['is_target'] == 1, 'Target'] = 'TG'
    return df

def calculate_percentile_cutoffs(df, columns_to_check=['c_len', 'c_num_of_genes']):
    cutoffs = {}
    for column in columns_to_check:
        if column in df.columns:
            percentile_cutoff = df[column].quantile(0.05)
            cutoffs[column] = percentile_cutoff
    return cutoffs

def label_below_cutoff(df, cutoffs):
    for column, cutoff in cutoffs.items():
        if column in df.columns:
            df.loc[(df['Target'] != 'TG') & (df[column] <= cutoff), 'Target'] = 'CT'
    return df

def label_remaining_rows(df):
    df.loc[df['Target'].isnull(), 'Target'] = 'CRT'
    return df

def extract_unique_taxon_names(df):
    return df[df['Target'] == 'CRT']['taxon_assignment'].unique()

def find_species_in_databases(unique_species_names, db_path):
    active_species_details = []
    total_species = len(unique_species_names)
    
    with tqdm(total=total_species, desc="Processing Species") as pbar:
        for species in unique_species_names:
            pbar.update(1)
            species_found = False
            
            for file in os.listdir(db_path):
                if file.startswith('db_') and file.endswith('.csv'):
                    source = file[3:-4]
                    file_path = os.path.join(db_path, file)
                    try:
                        df = pd.read_csv(file_path, delimiter='|')
                        species_data = df[df['organism_name'] == species].to_dict('records')
                        if species_data:
                            species_found = True
                            for data in species_data:
                                data['source'] = source
                                active_species_details.append(data)
                    except Exception as e:
                        print(f"Error processing file {file_path}: {e}")
            
            
            if not species_found:# if species is not found in any database file, add it to the list with status 'Taxaminar not available'
                active_species_details.append({'organism_name': species, 'status': 'Taxaminar not available'})
    
    return active_species_details

def apply_percentile_cutoff_to_reference(df_reference, columns_to_check):
    
    df_reference = df_reference[df_reference['plot_label'].notna() & (df_reference['plot_label'] != 'unassigned')]#filter out rows where 'plot_label' is 'unassigned' or empty
    
    cutoffs = calculate_percentile_cutoffs(df_reference, columns_to_check=['c_len', 'c_num_of_genes'])
    for column, cutoff in cutoffs.items():
        if column in df_reference.columns:
            df_reference.loc[df_reference[column] < cutoff, 'Target'] = 'CR'
            df_reference.loc[df_reference[column] >= cutoff, 'Target'] = 'HGT'
    return df_reference


initial_path = "/home/vishnu/refseq/test"# define initial and target directories
processed_path = "/home/vishnu/processed/test"
db_path = "/home/vishnu/db_vishnu"


for folder_name in os.listdir(initial_path):# iterate through each folder
    folder_path = os.path.join(initial_path, folder_name)
    if os.path.isdir(folder_path):

        
        for file_name in os.listdir(folder_path):# iterate through files in folder
            if file_name.endswith(".csv"):
                file_path = os.path.join(folder_path, file_name)
                
                df = pd.read_csv(file_path)# read csv file into DataFrame
                
                
                df = remove_unassigned_rows(df)
                df = mark_target_rows(df)
                cutoffs = calculate_percentile_cutoffs(df, columns_to_check= ['c_len', 'c_num_of_genes'])  #update with actual column names
                df = label_below_cutoff(df, cutoffs)
                df = label_remaining_rows(df)
                
                
                df_tgct = df[df['Target'].isin(['TG', 'CT'])].copy()#separate DataFrames based on 'Target' column
                df_crt = df[df['Target'] == 'CRT'].copy()
                
                
                target_folder_path = os.path.join(processed_path, folder_name)#save Dataframes to separate directories
                os.makedirs(target_folder_path, exist_ok=True)
                
                df_tgct.to_csv(os.path.join(target_folder_path, "TGCT.csv"), index=False)
                df_crt.to_csv(os.path.join(target_folder_path, "CRT.csv"), index=False)

                
                unique_species_names = extract_unique_taxon_names(df_crt)#unique taxon  names from CRT.csv
                
                
                active_species_details = find_species_in_databases(unique_species_names, db_path)#find species in databases
                
                
                unique_species_file_path = os.path.join(target_folder_path, "unique_species_details.csv")# save unique species details to file in the folder
                unique_species_df = pd.DataFrame(active_species_details)
                unique_species_df.to_csv(unique_species_file_path, index=False)


                
                df_CRT = pd.read_csv(os.path.join(target_folder_path, "CRT.csv"))# load CRT.csv into DataFrame

                
                unique_species_details_df = pd.read_csv(unique_species_file_path)#unique_species_details.csv into a DataFrame

                
                inactive_species = unique_species_details_df[unique_species_details_df['status'] != 'active']#filter rows with status not equal to "active"

                
                for index, row in inactive_species.iterrows():#iterate over each inactive species
                    organism_name = row['organism_name']
                    status = row['status']

                    
                    mask = df_CRT['taxon_assignment'] == organism_name#check if the organism_name exists in CRT.csv
                    if mask.any():
                        
                        df_CRT.loc[mask, 'Target'] = status # update the target column in df_CRT if the status is not "active"

                
                updated_crt_file_path = os.path.join(target_folder_path, "updated_CRT.csv")#save the updated df_CRT DataFrame
                df_CRT.to_csv(updated_crt_file_path, index=False)
                print(f"Updated CRT saved to {updated_crt_file_path}")

                 
                os.replace(updated_crt_file_path, os.path.join(target_folder_path, "CRT.csv"))#replace the old CRT.csv with updated_CRT.csv

                
                source_df = pd.read_csv(unique_species_file_path)#fetch assembly accession numbers for sources and apply percentile cutoffs
                dataframes = []

                for index, row in source_df.iterrows():
                    try:
                        source = row['source']
                        assembly_accession = row['assembly_accession']

                        
                        if pd.isna(source) or pd.isna(assembly_accession):#skip if source or assembly_accession is empty
                            print("Skipping row due to missing values.")
                            continue

                        source_folder = os.path.join("/home/vishnu/refseq", source)
                        gene_table_path = os.path.join(source_folder, assembly_accession, "gene_table_taxon_assignment.csv")
                    except Exception as e:
                        print(f"Error processing row {index}: {e}")
                        continue  #skip to the next row if an error occurs
                    try:
                        df_reference = pd.read_csv(gene_table_path)
                       
                        df_reference = df_reference[df_reference['plot_label'] != "Unassigned"] #remove rows with plot_label equal to "Unassigned"

                        df_reference = apply_percentile_cutoff_to_reference(df_reference,columns_to_check= ['c_len', 'c_num_of_genes'])
                        dataframes.append(df_reference)
                    except Exception as e:
                        print(f"Error processing file {gene_table_path}: {e}")

                
                try:

                    if dataframes:
                        merged_df = pd.concat(dataframes)
            
                        merged_df.to_csv(os.path.join(target_folder_path, "output.csv"), index=False)
                        print("Dataframes concatenated and saved successfully.")
                    else:
                        print("No dataframes found. Exiting without saving.")  

                except Exception as e:
                    print(f"Error processing file {file_path}: {e}")
                    continue  #skip to the next file
        
         
        crt_file_path = os.path.join(processed_path, folder_name, "CRT.csv")#load CRT.csv and output.csv for each folder
        output_file_path = os.path.join(processed_path, folder_name, "output.csv")
        
        if not os.path.exists(crt_file_path) or not os.path.exists(output_file_path):
            print(f"Files not found for folder: {folder_name}")
            continue
        
        df_CRT = pd.read_csv(crt_file_path)
        df_output = pd.read_csv(output_file_path)

        
        taxonomic_hits_dir = os.path.join("/home/vishnu/refseq/test", folder_name)#construct taxonomic_hits_path for the current folder
        taxonomic_hits_path = os.path.join(taxonomic_hits_dir, "taxonomic_hits.txt")

        if not os.path.exists(taxonomic_hits_path):
            print(f"Taxonomic hits file not found for folder: {folder_name}")
            continue

        
        taxonomic_hits_df = pd.read_csv(taxonomic_hits_path, sep='\t')#match df_CRT with taxonomic_hits.txt and find best hits

        
        best_hits = []

        # tqdm for progress indication
        for index, row in tqdm(df_CRT.iterrows(), total=df_CRT.shape[0], desc=f"Processing {folder_name}"):
            fasta_header, bh_pident, bh_evalue, bh_bitscore = row['fasta_header'], row['bh_pident'], row['bh_evalue'], row['bh_bitscore']
            match = taxonomic_hits_df[(taxonomic_hits_df['qseqid'] == fasta_header) & 
                                      (taxonomic_hits_df['pident'].astype(str) == str(bh_pident)) &
                                      (taxonomic_hits_df['evalue'].astype(str) == str(bh_evalue)) & 
                                      (taxonomic_hits_df['bitscore'].astype(str) == str(bh_bitscore))]
            if not match.empty:
                best_hits.append({'qseqid': match['qseqid'].values[0], 'sseqid': match['sseqid'].values[0]})

        
        df_besthits = pd.DataFrame(best_hits)#convert best hits to dataframe

        
        besthits_file_path = os.path.join(processed_path, folder_name, "best_hits.csv")#save df_besthits for further processing
        df_besthits.to_csv(besthits_file_path, index=False)

        print(f"Best hits saved to {besthits_file_path}")

        
        besthits_file_path = os.path.join(processed_path, folder_name, "best_hits.csv")#load the best hits DataFrame from the "best_hits.csv" file
        df_besthits = pd.read_csv(besthits_file_path)

# further processing and modifications are performed on df_besthits DataFrame .These modifications include adding columns based on data from other files and Finally, the updated DataFrame is saved to a new CSV file

        
        labelled_reference_file_path = os.path.join(processed_path, folder_name, "output.csv")#load the labelled reference DataFrame
        df_labelled_reference = pd.read_csv(labelled_reference_file_path)

        
        fasta_header_values = []
        target_values = []

        
        for sseqid in df_besthits['sseqid']:# Iterate over sseqid 
            
            match = df_labelled_reference[df_labelled_reference['fasta_header'].str.contains(sseqid, na=False)]# Search for sseqid 
            if not match.empty:
                
                fasta_header_values.append(match['fasta_header'].iloc[0])#append the corresponding fasta_header and Target values
                target_values.append(match['Target'].iloc[0])
            else:
                fasta_header_values.append('Not Found')
                target_values.append('Not Found')

        
        df_besthits['fasta_header'] = fasta_header_values# add the collected fasta_header and Target values as new columns in the best hits DataFrame
        df_besthits['Target'] = target_values
        updated_best_hits_file_path = os.path.join(processed_path, folder_name, "updated_best_hits.csv")#save the updated best hits DataFrame with the new columns
        df_besthits.to_csv(updated_best_hits_file_path, index=False)
        print(f"Updated Best Hits DataFrame saved to {updated_best_hits_file_path}")


        
        updated_best_hits_file_path = os.path.join(processed_path, folder_name, "updated_best_hits.csv")#load updated_best_hits.csv and CRT.csv for each folder
        crt_file_path = os.path.join(processed_path, folder_name, "CRT.csv")
        
        if not os.path.exists(updated_best_hits_file_path) or not os.path.exists(crt_file_path):
            print(f"Files not found for folder: {folder_name}")
            continue
        
        
        updated_besthit_df = pd.read_csv(updated_best_hits_file_path)#load updated_best_hits.csv and CRT.csv
        crt_df = pd.read_csv(crt_file_path)

        
        qseqid_target_dict = dict(zip(updated_besthit_df['qseqid'], updated_besthit_df['Target']))#initialize a dictionary to store qseqid and corresponding Target values from updated_besthit_df

        
        crt_with_crt_target = crt_df[crt_df['Target'] == 'CRT'].copy()#create a subset DataFrame where Target is 'CRT'

        
        for qseqid, target in qseqid_target_dict.items():#iterate through each qseqid and target value in the dictionary
            
            mask = crt_with_crt_target['fasta_header'].str.contains(qseqid, regex=False)#create a mask where the fasta_header contains the qseqid
            
            if mask.any():#use the mask to update the Target column for matching rows
                crt_with_crt_target.loc[mask, 'Target'] = target

        
        updated_crt_file_path = os.path.join(processed_path, folder_name, "updated_CRT.csv")#save the updated CRT DataFrame back to CSV
        crt_with_crt_target.to_csv(updated_crt_file_path, index=False)
        print(f"Updated CRT DataFrame saved to {updated_crt_file_path}")
        
        
    try:        
        
        crt_file_path = os.path.join(processed_path, folder_name, "CRT.csv")#load CRT.csv and updated_CRT.csv for each folder
        updated_crt_file_path = os.path.join(processed_path, folder_name, "updated_CRT.csv")

        
        df_CRT = pd.read_csv(crt_file_path)#load the original updated DataFrame

        
        
        updated_df_CRT = pd.read_csv(updated_crt_file_path)#load the newly updated DataFrame with specific target changes

        
        updated_fasta_headers = updated_df_CRT['fasta_header'].unique()#identify the rows in the original DataFrame that were updated (assuming 'fasta_header' can be used as a unique identifier)

        
        remaining_df_CRT = df_CRT[~df_CRT['fasta_header'].isin(updated_fasta_headers)]#remove these rows from the original DataFrame

        
        combined_df_CRT = pd.concat([remaining_df_CRT, updated_df_CRT], ignore_index=True)#combine the remaining rows of the original DataFrame with the newly updated rows

        
        #combined_df_CRT['target'] = combined_df_CRT['target'].apply(lambda x: 'besthit not found' if x == 'CRT' else x)#replace 'CRT' values in the 'target' column with 'besthit not found'

        combined_df_CRT_path = os.path.join(processed_path, folder_name, "combined_df_CRT.csv")#save the combined DataFrame
        combined_df_CRT.to_csv(combined_df_CRT_path, index=False)

        print(f"Combined DataFrame saved to {combined_df_CRT_path}")

        
        df_TGCT_path = os.path.join(processed_path, folder_name, "TGCT.csv")#load df_TGCT.csv
        df_TGCT = pd.read_csv(df_TGCT_path)

        
        combined_df_CRT_path = os.path.join(processed_path, folder_name, "combined_df_CRT.csv")#load combined_df_CRT.csv
        combined_df_CRT = pd.read_csv(combined_df_CRT_path)

        
        final_combined_df = pd.concat([df_TGCT, combined_df_CRT])#combine the two DataFrames

        
        final_combined_file_path = os.path.join(processed_path, folder_name, f"{folder_name}.csv")#save the final combined DataFrame with the name of the folder
        final_combined_df.to_csv(final_combined_file_path, index=False)

        print(f"Final combined DataFrame saved to {final_combined_file_path}")

    except Exception as e:
        
        print(f"Error processing folder {folder_name}: {e}")
        continue  #skip to the next folder if an error occurs