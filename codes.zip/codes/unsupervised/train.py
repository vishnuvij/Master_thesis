# Import the Model
from model import create_autoencoder

# Import Other libraries
import joblib
import argparse
from sklearn.metrics import silhouette_score, calinski_harabasz_score, davies_bouldin_score
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, classification_report
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.preprocessing import MinMaxScaler
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
import seaborn as sns
import tensorflow as tf
import warnings
import os
from sklearn.feature_selection import SelectKBest, f_classif
warnings.filterwarnings('ignore')



#Parse command-line arguments
parser = argparse.ArgumentParser(
    description='Train autoencoder and perform clustering.')
parser.add_argument('training_filename', type=str,
                    help='Filename of the training data.')
parser.add_argument('result_folder', type=str,
                    help='Folder to save results and models.')
args = parser.parse_args()


# Update paths according to arguments
training_file_path = args.training_filename
result_folder_path = args.result_folder

os.makedirs(result_folder_path, exist_ok=True)

#Change the training file name to one from the arguments
df = pd.read_csv(training_file_path, index_col=0)

df = df.drop('is_target', axis=1)

selected_columns =  ['c_num_of_genes', 'c_len', 'c_pct_assemby_len', 'c_genelenm',
       'c_genelensd', 'c_pearson_r', 'c_pearson_p', 'c_gc_cont', 'g_len',
       'g_lendev_c', 'g_lendev_o', 'g_abspos', 'g_single', 'g_pearson_r_o',
       'g_pearson_p_o', 'g_pearson_r_c', 'g_pearson_p_c', 'g_gc_cont',
       'g_gcdev_c', 'g_gcdev_o', 'PC_1', 'PC_2', 'PC_3', 
       'bh_pident', 'bh_evalue', 'bh_bitscore', 'start', 'end']

df = df[selected_columns]
df.isnull().sum()
# Drop NaN values rows in the selected columns
numeric_cols = df.select_dtypes(include=['float64', 'int64']).columns
df[numeric_cols] = df[numeric_cols].fillna(df[numeric_cols].mean())
df.dropna(inplace=True)

input_dim = df.shape[1]  # Number of features
encoding_dim = 10  # Dimension of the encoded representation

# Normalizing the data
scaler = MinMaxScaler()
# perform_feature_engineering(df, scaler)
scaler.fit(df)

df_normalized = scaler.transform(df)

# Creating the autoencoder and encoder models
autoencoder, encoder = create_autoencoder(input_dim, encoding_dim)

# Callback to save the best model based on validation loss
# Add folder name in front of filepath
best_model_checkpoint = tf.keras.callbacks.ModelCheckpoint(filepath=f'./{result_folder_path}/best_model_combined.keras',
                                                           save_best_only=True,
                                                           monitor='val_loss',
                                                           mode='min',
                                                           verbose=1)

# Callback to reduce learning rate on plateau
reduce_lr_on_plateau = tf.keras.callbacks.ReduceLROnPlateau(monitor='val_loss',
                                                            factor=0.9,
                                                            patience=10,
                                                            verbose=1,
                                                            mode='min',
                                                            min_lr=1e-6)  # Lower bound on the learning rate.

# Define early stopping callback
early_stopping = tf.keras.callbacks.EarlyStopping(
    monitor='val_loss',
    min_delta=0.001,
    patience=100,
    restore_best_weights=True,
    verbose=1
)

# Train the autoencoderr
history = autoencoder.fit(df_normalized, df_normalized,
                          epochs=10,
                          batch_size=256,
                          shuffle=True,
                          validation_split=0.2,
                          callbacks=[best_model_checkpoint, early_stopping, reduce_lr_on_plateau])


#Extract th eloss and validation loss from the history object
#Instead of showing, I want to save all the plots in the result_folder
loss = history.history['loss']
val_loss = history.history['val_loss']
epochs = range(1, len(loss) + 1)

#Plot
plt.figure(figsize=(10, 6))
plt.plot(epochs, loss, 'bo-', label='Training loss')
plt.plot(epochs, val_loss, 'ro-', label='Validation loss')
plt.title('Training and Validation Loss for Model 1')
plt.xlabel('Epochs')
plt.ylabel('Loss')
plt.legend()
plt.savefig(f'./{result_folder_path}/training_validation_loss.png')
plt.close()

# plt.show()

encoded_data = encoder.predict(df_normalized)
#Reduce data to two dimensions using PCA
pca = PCA(n_components=2)
principal_components = pca.fit_transform(encoded_data)
#Apply k-means clustering
kmeans = KMeans(n_clusters=3, random_state=0)
clusters = kmeans.fit_predict(encoded_data)
#Plotting the clusters
#Instead of showing, I want to save all the plots in the result_folder
plt.figure(figsize=(8, 6))
colors = ['red', 'green', 'blue']
for i in range(3):
    plt.scatter(principal_components[clusters == i, 0], principal_components[clusters == i, 1],
                s=100, c=colors[i], label=f'Cluster {i}')

plt.title('Clusters visualization in 2D PCA-reduced space')
plt.xlabel('Principal Component 1')
plt.ylabel('Principal Component 2')
plt.legend()
plt.savefig(f'./{result_folder_path}/training_scatter_plot.png')
plt.close()
# plt.show()

# Save the best model in the resitls_folder
encoder.save(f'./{result_folder_path}/encoder.keras')

# Save scaler 
joblib.dump(scaler, f'./{result_folder_path}/minmaxscaler.pkl')

# Save the PCA model
joblib.dump(pca, f'./{result_folder_path}/pca_model.pkl')

# Save the KMeans model
joblib.dump(kmeans, f'./{result_folder_path}/kmeans_model.pkl')
