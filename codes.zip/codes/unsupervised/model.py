from tensorflow.keras import layers, models


def create_autoencoder(input_dim, encoding_dim):
    # Encoder
    input_layer = layers.Input(shape=(input_dim,))
    x = layers.Dense(512, activation='linear',
                     )(input_layer)
    x = layers.LeakyReLU(alpha=0.1)(x)
    x = layers.BatchNormalization()(x)
    x = layers.Dropout(0.5)(x)
    x = layers.Dense(256, activation='linear',
                     )(x)
    x = layers.LeakyReLU(alpha=0.1)(x)
    x = layers.BatchNormalization()(x)
    x = layers.Dropout(0.5)(x)
    x = layers.Dense(128, activation='linear',
                     )(x)
    x = layers.LeakyReLU(alpha=0.1)(x)
    x = layers.BatchNormalization()(x)
    x = layers.Dropout(0.5)(x)
    x = layers.Dense(64, activation='relu')(x)
    encoded = layers.Dense(encoding_dim, activation='relu')(x)

    # Decoder
    x = layers.Dense(64, activation='relu')(encoded)
    x = layers.Dense(128, activation='linear',
                     )(x)
    x = layers.LeakyReLU(alpha=0.1)(x)
    x = layers.BatchNormalization()(x)
    x = layers.Dropout(0.5)(x)
    x = layers.Dense(256, activation='linear',
                     )(x)
    x = layers.LeakyReLU(alpha=0.1)(x)
    x = layers.BatchNormalization()(x)
    x = layers.Dropout(0.5)(x)
    x = layers.Dense(512, activation='linear',
                     )(x)
    x = layers.LeakyReLU(alpha=0.1)(x)
    x = layers.BatchNormalization()(x)
    decoded = layers.Dense(input_dim, activation='sigmoid')(x)

    # Autoencoder = Encoder + Decoder
    autoencoder = models.Model(inputs=input_layer, outputs=decoded)

    # Encoder model
    encoder = models.Model(inputs=input_layer, outputs=encoded)

    # Compile autoencoder
    autoencoder.compile(optimizer='adam', loss='mse')

    # autoencoder.summary()

    return autoencoder, encoder
