import joblib
import pandas as pd
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, classification_report, confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
import tensorflow as tf
import argparse
# Load the trained models and data for inference

parser = argparse.ArgumentParser(
    description='Evaluate clusters')
parser.add_argument('testing_file_name', type=str,
                    help='Filename of the testing data.')
parser.add_argument('folder_name', type=str,
                    help='Folder to get results and models.')
args = parser.parse_args()

testing_file_path = args.testing_file_name
folder_path = args.folder_name

scaler = joblib.load(f'./{folder_path}/minmaxscaler.pkl')
pca = joblib.load(f'./{folder_path}/pca_model.pkl')
kmeans = joblib.load(f'./{folder_path}/kmeans_model.pkl')
encoder = tf.keras.models.load_model(f'./{folder_path}/encoder.keras')

df = pd.read_csv(testing_file_path, index_col=0)
df = df[(df['is_target'] != 1) & (df['Target'] != 'Unknown') & (df['Target'] != 'Not Found') & (df['Target'] != 'TG') & (df['Target'] != 'Taxaminar not available') & (df['Target'] != 'CRT')]
df = df.drop('is_target', axis=1)  # Drop the target if it's present in the data
selected_columns = ['c_num_of_genes', 'c_len', 'c_pct_assemby_len', 'c_genelenm',
       'c_genelensd', 'c_pearson_r', 'c_pearson_p', 'c_gc_cont', 'g_len',
       'g_lendev_c', 'g_lendev_o', 'g_abspos', 'g_single', 'g_pearson_r_o',
       'g_pearson_p_o', 'g_pearson_r_c', 'g_pearson_p_c', 'g_gc_cont',
       'g_gcdev_c', 'g_gcdev_o', 'PC_1', 'PC_2', 'PC_3', 
       'bh_pident', 'bh_evalue', 'bh_bitscore', 'start', 'end','Target']
selected_columns_test = ['c_num_of_genes', 'c_len', 'c_pct_assemby_len', 'c_genelenm',
       'c_genelensd', 'c_pearson_r', 'c_pearson_p', 'c_gc_cont', 'g_len',
       'g_lendev_c', 'g_lendev_o', 'g_abspos', 'g_single', 'g_pearson_r_o',
       'g_pearson_p_o', 'g_pearson_r_c', 'g_pearson_p_c', 'g_gc_cont',
       'g_gcdev_c', 'g_gcdev_o', 'PC_1', 'PC_2', 'PC_3', 
       'bh_pident', 'bh_evalue', 'bh_bitscore', 'start', 'end']

df = df[selected_columns]
df.isnull().sum()

# Drop rows with NaN values in the selected columns
numeric_cols = df.select_dtypes(include=['float64', 'int64']).columns
df[numeric_cols] = df[numeric_cols].fillna(df[numeric_cols].mean())
df.dropna(inplace=True)
df = df[selected_columns_test]
test_data_df = df
test_df_normalized = scaler.transform(test_data_df)

test_encoded_data = encoder.predict(test_df_normalized)

test_principal_components = pca.transform(test_encoded_data)

test_clusters = kmeans.fit_predict(test_encoded_data)



plt.figure(figsize=(8, 6))
colors = ['red', 'green', 'blue']
for i in range(3):
    plt.scatter(test_principal_components[test_clusters == i, 0], test_principal_components[test_clusters == i, 1],
                s=100, c=colors[i], label=f'Cluster {i}')

plt.title('Clusters visualization in 2D PCA-reduced space')
plt.xlabel('Principal Component 1')
plt.ylabel('Principal Component 2')
plt.legend()
# plt.show()
plt.savefig(f'./{folder_path}/testing_scatter_plot.png')
plt.close()


df = pd.read_csv(testing_file_path, index_col=0)
df = df[(df['is_target'] != 1) & (df['Target'] != 'Unknown') & (df['Target'] != 'Not Found') & (df['Target'] != 'TG') & (df['Target'] != 'Taxaminar not available') & (df['Target'] != 'CRT')]
df = df.drop('is_target', axis=1)  # Drop the target if it's present in the data

selected_columns = ['c_num_of_genes', 'c_len', 'c_pct_assemby_len', 'c_genelenm',
       'c_genelensd', 'c_pearson_r', 'c_pearson_p', 'c_gc_cont', 'g_len',
       'g_lendev_c', 'g_lendev_o', 'g_abspos', 'g_single', 'g_pearson_r_o',
       'g_pearson_p_o', 'g_pearson_r_c', 'g_pearson_p_c', 'g_gc_cont',
       'g_gcdev_c', 'g_gcdev_o', 'PC_1', 'PC_2', 'PC_3', 
       'bh_pident', 'bh_evalue', 'bh_bitscore', 'start', 'end','Target']

df = df[selected_columns]
df.isnull().sum()
# Drop rows with NaN values in the selected columns
numeric_cols = df.select_dtypes(include=['float64', 'int64']).columns
df[numeric_cols] = df[numeric_cols].fillna(df[numeric_cols].mean())
df.dropna(inplace=True) # Drop the target if it's present in the data
uncleaned_test_data_df = df
# Create a confusion matrix using the bwloe outputsMake Confusion Matrix
total_test = uncleaned_test_data_df['Target'].value_counts().to_dict()
# {'HGT': 157, 'CR': 6, 'CT': 3}
cluster0 = uncleaned_test_data_df[test_clusters ==0]['Target'].value_counts().to_dict()
# {'HGT': 92, 'CR': 0, 'CT': 0}

cluster1 = uncleaned_test_data_df[test_clusters ==
                                  1]['Target'].value_counts().to_dict()
# {'HGT': 56, 'CR': 5, 'CT': 1}

cluster2 = uncleaned_test_data_df[test_clusters ==
                                  2]['Target'].value_counts().to_dict()
# {'HGT': 9, 'CR': 1, 'CT': 2}

cluster_outputs = {
    '0': cluster0,
    '1': cluster1,
    '2': cluster2
}

#DataFrame to hold the predicted clusters
predictions = []

#Assuming cluster 0 is predominantly 'HGT', cluster 1 is a mix (but still predominantly'HGT'), and cluster 2 is also 'HGT' based on your data
for cluster, counts in cluster_outputs.items():
    for target, count in counts.items():
        predictions.extend([(cluster, target)] * count)

#Convert predictions to a DataFrame
df_predictions = pd.DataFrame(
    predictions, columns=['PredictedCluster', 'Actual'])

#Count occurrences of each 'Actual' label within each 'PredictedCluster'
label_counts = df_predictions.groupby(['PredictedCluster', 'Actual']
                                      ).size().unstack(fill_value=0)

#Determine the most common 'Actual' label within each 'PredictedCluster'
most_common_labels = label_counts.idxmax(axis=1)

#Ensure unique assignment (no cluster is assigned more than one label)
cluster_to_target = {}
for cluster, label in most_common_labels.items():
    if label not in cluster_to_target.values():  # Check if label is already used
        cluster_to_target[str(cluster)] = label

#If any label is not directly assignable because of repetition, handle it separately
#This part might need custom logic based on specific rules or preferences
all_labels = set(['HGT', 'CR', 'CT'])
assigned_labels = set(cluster_to_target.values())
unassigned_labels = all_labels - assigned_labels

#ogic to assign remaining labels if direct assignment was not possible(Need more work)

for label in unassigned_labels:
    for cluster in most_common_labels.index:
        if cluster not in cluster_to_target and label not in cluster_to_target.values():
            cluster_to_target[str(cluster)] = label
            break

#mapping
df_predictions['Predicted'] = df_predictions['PredictedCluster'].map(cluster_to_target)


cm = pd.crosstab(df_predictions['Actual'], df_predictions['Predicted'], rownames=[
                 'Actual'], colnames=['Predicted'])


#Convert 'Actual' and 'Predicted' columns to lists for metric calculations
actual_labels = df_predictions['Actual'].tolist()
predicted_labels = df_predictions['Predicted'].tolist()
# Add predicted labels to the initial DataFrame
df['Predicted_Labels'] = df_predictions['Predicted'].values

#Save the DataFrame with predicted labels
df.to_csv(f'./{folder_path}/predicted_labels_clusters.csv', index=True)
#Calculate Accuracy
accuracy = accuracy_score(actual_labels, predicted_labels)


precision = precision_score(
    actual_labels, predicted_labels, average='weighted')
recall = recall_score(actual_labels, predicted_labels, average='weighted')
f1 = f1_score(actual_labels, predicted_labels, average='weighted')


with open(f'./{folder_path}/result.txt', 'w') as f:
    f.write(f"Accuracy: {accuracy}\n")
    f.write(f"Precision: {precision}\n")
    f.write(f"Recall: {recall}\n")
    f.write(f"F1-score: {f1}\n")
    f.write("Classification Report:")
    f.write(f"{classification_report(actual_labels, predicted_labels)}")

print(f'Accuracy: {accuracy}')
print(f'Precision: {precision}')
print(f'Recall: {recall}')
print(f'F1-score: {f1}')

#classification report
print(classification_report(actual_labels, predicted_labels, zero_division = 0))



#Plot confusion matrix
plt.figure(figsize=(10, 7))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues')
plt.title('Confusion Matrix')
plt.savefig(f'{folder_path}/confusion_matrix.png')
plt.close()
# plt.show()
